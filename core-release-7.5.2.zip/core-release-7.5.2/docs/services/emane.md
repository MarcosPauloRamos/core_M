# EMANE Services

* Table of Contents
{:toc}

## Overview

EMANE related services for CORE.

## Transport Service

Helps with setting up EMANE for using an external transport.

